package com.example.project_group3_act2c;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;
import java.util.Random;

public class RegisterActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPhone, etPassword, etConfirm, etPhoneOtp;
    private ImageView ivTogglePassword, ivToggleConfirm;
    private Button btnRegister, btnVerifyPhoneOtp;
    private ProgressBar progressBar;
    private LinearLayout layoutPhoneOtp;
    private SharedPreferences prefs;

    private boolean isPasswordVisible = false;
    private boolean isConfirmVisible = false;
    private String generatedPhoneOtp = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etPassword = findViewById(R.id.etPassword);
        etConfirm = findViewById(R.id.etConfirm);
        ivTogglePassword = findViewById(R.id.ivTogglePassword);
        ivToggleConfirm = findViewById(R.id.ivToggleConfirm);
        btnRegister = findViewById(R.id.btnRegister);
        progressBar = findViewById(R.id.progressBar);

        layoutPhoneOtp = findViewById(R.id.layoutPhoneOtp);
        etPhoneOtp = findViewById(R.id.etPhoneOtp);
        btnVerifyPhoneOtp = findViewById(R.id.btnVerifyPhoneOtp);

        TextView tvBackLogin = findViewById(R.id.tvBackLogin);

        prefs = getSharedPreferences("UserData", MODE_PRIVATE);

        if (ivTogglePassword != null) {
            ivTogglePassword.setOnClickListener(v -> {
                isPasswordVisible = !isPasswordVisible;
                if (isPasswordVisible) {
                    etPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    ivTogglePassword.setImageResource(R.drawable.ic_eye);
                } else {
                    etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    ivTogglePassword.setImageResource(R.drawable.ic_eye_off);
                }
                etPassword.setSelection(etPassword.getText().length());
            });
        }

        if (ivToggleConfirm != null) {
            ivToggleConfirm.setOnClickListener(v -> {
                isConfirmVisible = !isConfirmVisible;
                if (isConfirmVisible) {
                    etConfirm.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    ivToggleConfirm.setImageResource(R.drawable.ic_eye);
                } else {
                    etConfirm.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    ivToggleConfirm.setImageResource(R.drawable.ic_eye_off);
                }
                etConfirm.setSelection(etConfirm.getText().length());
            });
        }

        btnRegister.setOnClickListener(v -> initiateRegistrationAndSendOtp());

        btnVerifyPhoneOtp.setOnClickListener(v -> verifyPhoneOtpAndRegister());

        tvBackLogin.setOnClickListener(v -> finish());
    }

    private void initiateRegistrationAndSendOtp() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String password = etPassword.getText().toString();
        String confirm = etConfirm.getText().toString();

        if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || password.isEmpty() || confirm.isEmpty()) {
            Toast.makeText(this, "Please complete all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Invalid email", Toast.LENGTH_SHORT).show();
            return;
        }

        if (phone.length() < 7) {
            Toast.makeText(this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 6) {
            Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(confirm)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        btnRegister.setEnabled(false);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            progressBar.setVisibility(View.GONE);
            btnRegister.setEnabled(true);

            generatedPhoneOtp = String.format(Locale.getDefault(), "%04d", new Random().nextInt(10000));
            Toast.makeText(this, "Phone OTP Sent to " + phone + ": " + generatedPhoneOtp, Toast.LENGTH_LONG).show();

            layoutPhoneOtp.setVisibility(View.VISIBLE);
            etPhoneOtp.requestFocus();
        }, 800);
    }

    private void verifyPhoneOtpAndRegister() {
        String inputOtp = etPhoneOtp.getText().toString().trim();

        if (inputOtp.isEmpty()) {
            Toast.makeText(this, "Please enter the OTP code", Toast.LENGTH_SHORT).show();
            return;
        }

        if (inputOtp.equals(generatedPhoneOtp)) {
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();
            String password = etPassword.getText().toString();

            prefs.edit()
                    .putString("name", name)
                    .putString("email", email)
                    .putString("phone", phone)
                    .putString("password", password)
                    .apply();

            DatabaseHelper dbHelper = new DatabaseHelper(RegisterActivity.this);
            dbHelper.registerOrUpdateUser(name, email, phone, password);

            Toast.makeText(this, "Phone Verified & Registration successful!", Toast.LENGTH_LONG).show();

            Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Incorrect Phone OTP code. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }
}
