package com.example.project_group3_act2c;

public class SlotModel {
    private String timeSlot;
    private int maxCapacity;
    private int bookedCount;
    private boolean isAvailable;

    public SlotModel(String timeSlot, int maxCapacity, int bookedCount) {
        this.timeSlot = timeSlot;
        this.maxCapacity = maxCapacity;
        this.bookedCount = bookedCount;
        this.isAvailable = bookedCount < maxCapacity;
    }

    public String getTimeSlot() { return timeSlot; }
    public int getMaxCapacity() { return maxCapacity; }
    public int getBookedCount() { return bookedCount; }
    public int getRemainingCount() { return Math.max(0, maxCapacity - bookedCount); }
    public boolean isAvailable() { return isAvailable; }
}
