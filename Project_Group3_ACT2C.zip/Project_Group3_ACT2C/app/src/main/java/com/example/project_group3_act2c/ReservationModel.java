package com.example.project_group3_act2c;

public class ReservationModel {
    private int id;
    private String userEmail;
    private String userName;
    private String userPhone;
    private String restaurantName;
    private String resDate;
    private String resTimeSlot;
    private int guestsCount;
    private String specialNotes;
    private String status; // "CONFIRMED", "PENDING", "CANCELLED", "COMPLETED"
    private String createdAt;

    public ReservationModel(int id, String userEmail, String userName, String userPhone,
                            String restaurantName, String resDate, String resTimeSlot,
                            int guestsCount, String specialNotes, String status, String createdAt) {
        this.id = id;
        this.userEmail = userEmail;
        this.userName = userName;
        this.userPhone = userPhone;
        this.restaurantName = restaurantName;
        this.resDate = resDate;
        this.resTimeSlot = resTimeSlot;
        this.guestsCount = guestsCount;
        this.specialNotes = specialNotes;
        this.status = status;
        this.createdAt = createdAt;
    }

    public int getId() { return id; }
    public String getUserEmail() { return userEmail; }
    public String getUserName() { return userName; }
    public String getUserPhone() { return userPhone; }
    public String getRestaurantName() { return restaurantName; }
    public String getResDate() { return resDate; }
    public String getResTimeSlot() { return resTimeSlot; }
    public int getGuestsCount() { return guestsCount; }
    public String getSpecialNotes() { return specialNotes; }
    public String getStatus() { return status; }
    public String getCreatedAt() { return createdAt; }

    public void setStatus(String status) { this.status = status; }
}
