package com.example.project_group3_act2c;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ReservationAdapter extends RecyclerView.Adapter<ReservationAdapter.ViewHolder> {

    public interface OnReservationActionListener {
        void onCancel(ReservationModel reservation);
        void onApprove(ReservationModel reservation);
        void onComplete(ReservationModel reservation);
        void onDelete(ReservationModel reservation);
    }

    private Context context;
    private List<ReservationModel> reservationList;
    private boolean isAdmin;
    private OnReservationActionListener listener;

    public ReservationAdapter(Context context, List<ReservationModel> reservationList, boolean isAdmin, OnReservationActionListener listener) {
        this.context = context;
        this.reservationList = reservationList;
        this.isAdmin = isAdmin;
        this.listener = listener;
    }

    public void setReservations(List<ReservationModel> newReservations) {
        this.reservationList = newReservations;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_reservation, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ReservationModel res = reservationList.get(position);

        holder.tvItemRestaurant.setText(res.getRestaurantName());
        holder.tvItemDateTime.setText("📅 " + res.getResDate() + " | ⏰ " + res.getResTimeSlot());
        holder.tvItemGuests.setText("👥 " + res.getGuestsCount() + " Guests");

        if (isAdmin) {
            holder.tvItemCustomerInfo.setVisibility(View.VISIBLE);
            holder.tvItemCustomerInfo.setText("Customer: " + res.getUserName() + " (" + res.getUserEmail() + " | " + res.getUserPhone() + ")");
        } else {
            holder.tvItemCustomerInfo.setVisibility(View.GONE);
        }

        if (res.getSpecialNotes() != null && !res.getSpecialNotes().trim().isEmpty()) {
            holder.tvItemNotes.setText("Note: " + res.getSpecialNotes().trim());
            holder.tvItemNotes.setVisibility(View.VISIBLE);
        } else {
            holder.tvItemNotes.setVisibility(View.GONE);
        }

        String status = res.getStatus();
        holder.tvItemStatus.setText(status);

        switch (status) {
            case "CONFIRMED":
                holder.tvItemStatus.setBackgroundResource(R.drawable.bg_badge_confirmed);
                break;
            case "PENDING":
                holder.tvItemStatus.setBackgroundResource(R.drawable.bg_badge_pending);
                break;
            case "CANCELLED":
                holder.tvItemStatus.setBackgroundResource(R.drawable.bg_badge_cancelled);
                break;
            case "COMPLETED":
                holder.tvItemStatus.setBackgroundResource(R.drawable.bg_badge_completed);
                break;
            default:
                holder.tvItemStatus.setBackgroundResource(R.drawable.bg_badge_pending);
                break;
        }

        if ("CANCELLED".equals(status) || "COMPLETED".equals(status)) {
            holder.btnCancel.setVisibility(View.GONE);
            holder.btnApprove.setVisibility(View.GONE);
            holder.btnComplete.setVisibility(View.GONE);
        } else {
            holder.btnCancel.setVisibility(View.VISIBLE);
            if (isAdmin) {
                if ("PENDING".equals(status)) {
                    holder.btnApprove.setVisibility(View.VISIBLE);
                } else {
                    holder.btnApprove.setVisibility(View.GONE);
                }
                holder.btnComplete.setVisibility(View.VISIBLE);
            } else {
                holder.btnApprove.setVisibility(View.GONE);
                holder.btnComplete.setVisibility(View.GONE);
            }
        }

        if (isAdmin) {
            holder.btnDelete.setVisibility(View.VISIBLE);
        } else {
            holder.btnDelete.setVisibility(View.GONE);
        }

        // Click listeners
        holder.btnCancel.setOnClickListener(v -> {
            if (listener != null) listener.onCancel(res);
        });

        holder.btnApprove.setOnClickListener(v -> {
            if (listener != null) listener.onApprove(res);
        });

        holder.btnComplete.setOnClickListener(v -> {
            if (listener != null) listener.onComplete(res);
        });

        holder.btnDelete.setOnClickListener(v -> {
            if (listener != null) listener.onDelete(res);
        });
    }

    @Override
    public int getItemCount() {
        return reservationList != null ? reservationList.size() : 0;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvItemRestaurant, tvItemStatus, tvItemCustomerInfo, tvItemDateTime, tvItemGuests, tvItemNotes;
        Button btnApprove, btnComplete, btnCancel, btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvItemRestaurant = itemView.findViewById(R.id.tvItemRestaurant);
            tvItemStatus = itemView.findViewById(R.id.tvItemStatus);
            tvItemCustomerInfo = itemView.findViewById(R.id.tvItemCustomerInfo);
            tvItemDateTime = itemView.findViewById(R.id.tvItemDateTime);
            tvItemGuests = itemView.findViewById(R.id.tvItemGuests);
            tvItemNotes = itemView.findViewById(R.id.tvItemNotes);

            btnApprove = itemView.findViewById(R.id.btnApprove);
            btnComplete = itemView.findViewById(R.id.btnComplete);
            btnCancel = itemView.findViewById(R.id.btnCancel);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
