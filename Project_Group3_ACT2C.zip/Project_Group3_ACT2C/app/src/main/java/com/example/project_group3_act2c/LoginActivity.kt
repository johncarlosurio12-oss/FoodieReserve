package com.example.project_group3_act2c

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class LoginActivity : AppCompatActivity() {
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var ivTogglePassword: ImageView
    private lateinit var cbRememberMe: CheckBox
    private lateinit var btnLogin: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var layoutOtp: LinearLayout
    private lateinit var etOtp: EditText
    private lateinit var btnVerifyOtp: Button
    private lateinit var prefs: SharedPreferences
    private var isPasswordVisible: Boolean = false
    private var generatedOtp: String = ""
    private var pendingTargetIntentClass: Class<*>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        ivTogglePassword = findViewById(R.id.ivTogglePassword)
        cbRememberMe = findViewById(R.id.cbRememberMe)
        btnLogin = findViewById(R.id.btnLogin)
        progressBar = findViewById(R.id.progressBar)
        layoutOtp = findViewById(R.id.layoutOtp)
        etOtp = findViewById(R.id.etOtp)
        btnVerifyOtp = findViewById(R.id.btnVerifyOtp)

        val tvRegister = findViewById<TextView>(R.id.tvRegister)
        val tvForgot = findViewById<TextView>(R.id.tvForgot)

        prefs = getSharedPreferences("UserData", MODE_PRIVATE)

        val isRemembered = prefs.getBoolean("remember_me", false)
        if (isRemembered) {
            etEmail.setText(prefs.getString("remember_email", ""))
            etPassword.setText(prefs.getString("remember_password", ""))
            cbRememberMe.isChecked = true
        }

        // Eye icon toggle for password visibility
        ivTogglePassword.setOnClickListener {
            isPasswordVisible = !isPasswordVisible
            if (isPasswordVisible) {
                etPassword.transformationMethod = HideReturnsTransformationMethod.getInstance()
                ivTogglePassword.setImageResource(R.drawable.ic_eye)
            } else {
                etPassword.transformationMethod = PasswordTransformationMethod.getInstance()
                ivTogglePassword.setImageResource(R.drawable.ic_eye_off)
            }
            etPassword.setSelection(etPassword.text.length)
        }

        btnLogin.setOnClickListener { initiateLogin() }

        btnVerifyOtp.setOnClickListener { verifyOtpAndProceed() }

        tvRegister.setOnClickListener {
            val intent = Intent(this@LoginActivity, RegisterActivity::class.java)
            startActivity(intent)
        }

        tvForgot.setOnClickListener {
            val intent = Intent(this@LoginActivity, ForgotPasswordActivity::class.java)
            startActivity(intent)
        }
    }

    private fun initiateLogin() {
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString()

        val savedEmail = prefs.getString("email", "") ?: ""
        val savedPassword = prefs.getString("password", "") ?: ""

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(
                this,
                "Please enter email and password",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val isAdminEmail = email.equals("admin@gmail.com", ignoreCase = true) || email.equals("admin", ignoreCase = true)
        val isAdminValid = isAdminEmail && password == "admin123"
        val isUserValid = email == savedEmail && password == savedPassword

        if (!isAdminValid && !isUserValid) {
            Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show()
            return
        }

        if (cbRememberMe.isChecked) {
            prefs.edit()
                .putBoolean("remember_me", true)
                .putString("remember_email", email)
                .putString("remember_password", password)
                .apply()
        } else {
            prefs.edit()
                .putBoolean("remember_me", false)
                .remove("remember_email")
                .remove("remember_password")
                .apply()
        }

        pendingTargetIntentClass = if (isAdminValid) AdminDashboardActivity::class.java else DashboardActivity::class.java
        progressBar.visibility = View.VISIBLE
        btnLogin.isEnabled = false

        Handler(Looper.getMainLooper()).postDelayed({
            progressBar.visibility = View.GONE
            btnLogin.isEnabled = true

            generatedOtp = String.format(java.util.Locale.getDefault(), "%04d", Random.nextInt(10000))
            Toast.makeText(this, "OTP Code Sent: $generatedOtp", Toast.LENGTH_LONG).show()

            layoutOtp.visibility = View.VISIBLE
            etOtp.requestFocus()
        }, 800)
    }

    private fun verifyOtpAndProceed() {
        val inputOtp = etOtp.text.toString().trim()

        if (inputOtp.isEmpty()) {
            Toast.makeText(this, "Please enter the OTP code", Toast.LENGTH_SHORT).show()
            return
        }

        if (inputOtp == generatedOtp) {
            Toast.makeText(this, "OTP Verified! Logging in...", Toast.LENGTH_SHORT).show()

            val savedEmail = prefs.getString("email", "") ?: ""
            val savedName = prefs.getString("name", "User") ?: "User"
            val savedPhone = prefs.getString("phone", "N/A") ?: "N/A"
            val savedPassword = prefs.getString("password", "") ?: ""

            if (savedEmail.isNotEmpty()) {
                val dbHelper = DatabaseHelper(this)
                dbHelper.registerOrUpdateUser(savedName, savedEmail, savedPhone, savedPassword)
            }

            val targetClass = pendingTargetIntentClass ?: DashboardActivity::class.java
            val intent = Intent(this@LoginActivity, targetClass)
            startActivity(intent)
            finish()
        } else {
            Toast.makeText(this, "Incorrect OTP. Please try again.", Toast.LENGTH_SHORT).show()
        }
    }
}
