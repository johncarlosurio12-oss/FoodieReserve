package com.example.project_group3_act2c;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SlotAdapter extends RecyclerView.Adapter<SlotAdapter.SlotViewHolder> {

    public interface OnSlotSelectedListener {
        void onSlotSelected(SlotModel slot);
    }

    private Context context;
    private List<SlotModel> slotList;
    private OnSlotSelectedListener listener;
    private int selectedPosition = -1;

    public SlotAdapter(Context context, List<SlotModel> slotList, OnSlotSelectedListener listener) {
        this.context = context;
        this.slotList = slotList;
        this.listener = listener;
    }

    public void setSlots(List<SlotModel> slotList) {
        this.slotList = slotList;
        this.selectedPosition = -1;
        notifyDataSetChanged();
    }

    public SlotModel getSelectedSlot() {
        if (selectedPosition >= 0 && selectedPosition < slotList.size()) {
            return slotList.get(selectedPosition);
        }
        return null;
    }

    @NonNull
    @Override
    public SlotViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_slot_chip, parent, false);
        return new SlotViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SlotViewHolder holder, int position) {
        SlotModel slot = slotList.get(position);
        holder.tvSlotTime.setText(slot.getTimeSlot());

        if (!slot.isAvailable()) {
            holder.containerSlot.setBackgroundResource(R.drawable.bg_slot_full);
            holder.tvSlotTime.setTextColor(Color.parseColor("#9CA3AF"));
            holder.tvSlotStatus.setText("FULL / BOOKED");
            holder.tvSlotStatus.setTextColor(Color.parseColor("#EF4444"));
            holder.containerSlot.setOnClickListener(v ->
                    Toast.makeText(context, "This slot is fully booked. Please choose another time slot.", Toast.LENGTH_SHORT).show());
        } else {
            holder.tvSlotStatus.setText(slot.getRemainingCount() + " slot(s) left");
            holder.tvSlotStatus.setTextColor(Color.parseColor("#059669"));

            if (position == selectedPosition) {
                holder.containerSlot.setBackgroundResource(R.drawable.bg_slot_selected);
                holder.tvSlotTime.setTextColor(Color.WHITE);
                holder.tvSlotStatus.setTextColor(Color.WHITE);
            } else {
                holder.containerSlot.setBackgroundResource(R.drawable.bg_slot_unselected);
                holder.tvSlotTime.setTextColor(Color.parseColor("#1F2937"));
            }

            holder.containerSlot.setOnClickListener(v -> {
                int previousSelected = selectedPosition;
                selectedPosition = holder.getAdapterPosition();
                notifyItemChanged(previousSelected);
                notifyItemChanged(selectedPosition);

                if (listener != null) {
                    listener.onSlotSelected(slot);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return slotList != null ? slotList.size() : 0;
    }

    static class SlotViewHolder extends RecyclerView.ViewHolder {
        LinearLayout containerSlot;
        TextView tvSlotTime;
        TextView tvSlotStatus;

        public SlotViewHolder(@NonNull View itemView) {
            super(itemView);
            containerSlot = itemView.findViewById(R.id.containerSlot);
            tvSlotTime = itemView.findViewById(R.id.tvSlotTime);
            tvSlotStatus = itemView.findViewById(R.id.tvSlotStatus);
        }
    }
}
