package com.example.project_group3_act2c;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    private TextView tvWelcome;
    private TextView tvNoReservations;
    private RecyclerView rvUserReservations;
    private ProgressBar progressBar;

    private DatabaseHelper dbHelper;
    private ReservationAdapter reservationAdapter;
    private String userEmail = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        dbHelper = new DatabaseHelper(this);

        tvWelcome = findViewById(R.id.tvWelcome);
        tvNoReservations = findViewById(R.id.tvNoReservations);
        rvUserReservations = findViewById(R.id.rvUserReservations);
        progressBar = findViewById(R.id.progressBar);

        Button btnReserve = findViewById(R.id.btnReserve);
        Button btnLogout = findViewById(R.id.btnLogout);

        TextView tvManam = findViewById(R.id.tvManam);
        TextView tvKuyaJ = findViewById(R.id.tvKuyaJ);
        TextView tvGerrys = findViewById(R.id.tvGerrys);
        TextView tvBarrioFiesta = findViewById(R.id.tvBarrioFiesta);
        TextView tvJollibee = findViewById(R.id.tvJollibee);
        TextView tvMcDonalds = findViewById(R.id.tvMcDonalds);
        TextView tvMangInasal = findViewById(R.id.tvMangInasal);

        SharedPreferences userPrefs = getSharedPreferences("UserData", MODE_PRIVATE);
        String name = userPrefs.getString("name", "Guest");
        userEmail = userPrefs.getString("email", "guest@foodie.com");

        tvWelcome.setText(getString(R.string.welcome_format, name));

        rvUserReservations.setLayoutManager(new LinearLayoutManager(this));
        reservationAdapter = new ReservationAdapter(this, null, false, new ReservationAdapter.OnReservationActionListener() {
            @Override
            public void onCancel(ReservationModel reservation) {
                cancelReservation(reservation);
            }

            @Override
            public void onApprove(ReservationModel reservation) {}

            @Override
            public void onComplete(ReservationModel reservation) {}

            @Override
            public void onDelete(ReservationModel reservation) {}
        });
        rvUserReservations.setAdapter(reservationAdapter);

        btnReserve.setOnClickListener(v -> openReservation(""));

        if (tvManam != null) {
            tvManam.setOnClickListener(v -> openReservation("Manam Comfort Filipino"));
        }
        if (tvKuyaJ != null) {
            tvKuyaJ.setOnClickListener(v -> openReservation("Kuya J Restaurant"));
        }
        if (tvGerrys != null) {
            tvGerrys.setOnClickListener(v -> openReservation("Gerry's Grill"));
        }
        if (tvBarrioFiesta != null) {
            tvBarrioFiesta.setOnClickListener(v -> openReservation("Barrio Fiesta"));
        }
        if (tvJollibee != null) {
            tvJollibee.setOnClickListener(v -> openReservation("Jollibee"));
        }
        if (tvMcDonalds != null) {
            tvMcDonalds.setOnClickListener(v -> openReservation("McDonald's"));
        }
        if (tvMangInasal != null) {
            tvMangInasal.setOnClickListener(v -> openReservation("Mang Inasal"));
        }

        btnLogout.setOnClickListener(v -> {
            if (progressBar != null) {
                progressBar.setVisibility(View.VISIBLE);
            }
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (progressBar != null) {
                    progressBar.setVisibility(View.GONE);
                }
                Intent intent = new Intent(DashboardActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }, 500);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadUserReservations();
    }

    private void openReservation(String restaurantName) {
        if (progressBar != null) {
            progressBar.setVisibility(View.VISIBLE);
        }
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (progressBar != null) {
                progressBar.setVisibility(View.GONE);
            }
            Intent intent = new Intent(DashboardActivity.this, ReservationActivity.class);
            if (!restaurantName.isEmpty()) {
                intent.putExtra("restaurant_name", restaurantName);
            }
            startActivity(intent);
        }, 300);
    }

    private void loadUserReservations() {
        List<ReservationModel> list = dbHelper.getReservationsForUser(userEmail);

        if (list == null || list.isEmpty()) {
            tvNoReservations.setVisibility(View.VISIBLE);
            rvUserReservations.setVisibility(View.GONE);
        } else {
            tvNoReservations.setVisibility(View.GONE);
            rvUserReservations.setVisibility(View.VISIBLE);
            reservationAdapter.setReservations(list);
        }
    }

    private void cancelReservation(ReservationModel reservation) {
        if (progressBar != null) {
            progressBar.setVisibility(View.VISIBLE);
        }
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (progressBar != null) {
                progressBar.setVisibility(View.GONE);
            }
            boolean success = dbHelper.updateReservationStatus(reservation.getId(), "CANCELLED");
            if (success) {
                Toast.makeText(this, "Reservation cancelled successfully", Toast.LENGTH_SHORT).show();

                // Clear legacy SharedPreferences
                SharedPreferences prefs = getSharedPreferences("ReservationData", MODE_PRIVATE);
                prefs.edit().clear().apply();

                loadUserReservations();
            } else {
                Toast.makeText(this, "Failed to cancel reservation", Toast.LENGTH_SHORT).show();
            }
        }, 400);
    }
}
