package com.example.project_group3_act2c;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "FoodieReserve.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_USERS = "users";
    private static final String KEY_USER_ID = "id";
    private static final String KEY_USER_NAME = "name";
    private static final String KEY_USER_EMAIL = "email";
    private static final String KEY_USER_PHONE = "phone";
    private static final String KEY_USER_PASSWORD = "password";
    private static final String KEY_USER_ROLE = "role";

    private static final String TABLE_RESTAURANTS = "restaurants";
    private static final String KEY_REST_ID = "id";
    private static final String KEY_REST_NAME = "name";
    private static final String KEY_REST_CUISINE = "cuisine";
    private static final String KEY_REST_CAPACITY = "capacity_per_slot";

    private static final String TABLE_RESERVATIONS = "reservations";
    private static final String KEY_RES_ID = "id";
    private static final String KEY_RES_USER_EMAIL = "user_email";
    private static final String KEY_RES_USER_NAME = "user_name";
    private static final String KEY_RES_USER_PHONE = "user_phone";
    private static final String KEY_RES_RESTAURANT = "restaurant_name";
    private static final String KEY_RES_DATE = "res_date";
    private static final String KEY_RES_TIME_SLOT = "res_time_slot";
    private static final String KEY_RES_GUESTS = "guests_count";
    private static final String KEY_RES_NOTES = "special_notes";
    private static final String KEY_RES_STATUS = "status";
    private static final String KEY_RES_CREATED_AT = "created_at";

    public static final String[] DEFAULT_TIME_SLOTS = new String[]{
            "10:00 AM - 11:30 AM",
            "11:30 AM - 01:00 PM",
            "01:00 PM - 02:30 PM",
            "05:00 PM - 06:30 PM",
            "06:30 PM - 08:00 PM",
            "08:00 PM - 09:30 PM"
    };

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + KEY_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_USER_NAME + " TEXT,"
                + KEY_USER_EMAIL + " TEXT UNIQUE,"
                + KEY_USER_PHONE + " TEXT,"
                + KEY_USER_PASSWORD + " TEXT,"
                + KEY_USER_ROLE + " TEXT" + ")";

        String CREATE_RESTAURANTS_TABLE = "CREATE TABLE " + TABLE_RESTAURANTS + "("
                + KEY_REST_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_REST_NAME + " TEXT UNIQUE,"
                + KEY_REST_CUISINE + " TEXT,"
                + KEY_REST_CAPACITY + " INTEGER" + ")";

        String CREATE_RESERVATIONS_TABLE = "CREATE TABLE " + TABLE_RESERVATIONS + "("
                + KEY_RES_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_RES_USER_EMAIL + " TEXT,"
                + KEY_RES_USER_NAME + " TEXT,"
                + KEY_RES_USER_PHONE + " TEXT,"
                + KEY_RES_RESTAURANT + " TEXT,"
                + KEY_RES_DATE + " TEXT,"
                + KEY_RES_TIME_SLOT + " TEXT,"
                + KEY_RES_GUESTS + " INTEGER,"
                + KEY_RES_NOTES + " TEXT,"
                + KEY_RES_STATUS + " TEXT,"
                + KEY_RES_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP" + ")";

        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_RESTAURANTS_TABLE);
        db.execSQL(CREATE_RESERVATIONS_TABLE);

        ContentValues adminCv = new ContentValues();
        adminCv.put(KEY_USER_NAME, "System Admin");
        adminCv.put(KEY_USER_EMAIL, "admin@gmail.com");
        adminCv.put(KEY_USER_PHONE, "09123456789");
        adminCv.put(KEY_USER_PASSWORD, "admin123");
        adminCv.put(KEY_USER_ROLE, "ADMIN");
        db.insertWithOnConflict(TABLE_USERS, null, adminCv, SQLiteDatabase.CONFLICT_IGNORE);

        seedRestaurant(db, "Manam Comfort Filipino", "Filipino Cuisine", 5);
        seedRestaurant(db, "Kuya J Restaurant", "Filipino Cuisine", 5);
        seedRestaurant(db, "Gerry's Grill", "Filipino Grill & Seafood", 5);
        seedRestaurant(db, "Barrio Fiesta", "Traditional Filipino", 5);
        seedRestaurant(db, "Jollibee", "Filipino Fast Food", 5);
        seedRestaurant(db, "McDonald's", "Fast Food", 5);
        seedRestaurant(db, "Mang Inasal", "Filipino Bbq & Grill", 5);
    }

    private void seedRestaurant(SQLiteDatabase db, String name, String cuisine, int capacity) {
        ContentValues cv = new ContentValues();
        cv.put(KEY_REST_NAME, name);
        cv.put(KEY_REST_CUISINE, cuisine);
        cv.put(KEY_REST_CAPACITY, capacity);
        db.insertWithOnConflict(TABLE_RESTAURANTS, null, cv, SQLiteDatabase.CONFLICT_IGNORE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RESTAURANTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RESERVATIONS);
        onCreate(db);
    }

    public boolean registerOrUpdateUser(String name, String email, String phone, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(KEY_USER_NAME, name);
        cv.put(KEY_USER_EMAIL, email);
        cv.put(KEY_USER_PHONE, phone);
        cv.put(KEY_USER_PASSWORD, password);
        cv.put(KEY_USER_ROLE, "USER");

        long result = db.insertWithOnConflict(TABLE_USERS, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
        return result != -1;
    }

    public List<UserModel> getAllUsers() {
        List<UserModel> users = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " ORDER BY " + KEY_USER_ID + " DESC", null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_USER_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(KEY_USER_NAME));
                String email = cursor.getString(cursor.getColumnIndexOrThrow(KEY_USER_EMAIL));
                String phone = cursor.getString(cursor.getColumnIndexOrThrow(KEY_USER_PHONE));
                String role = cursor.getString(cursor.getColumnIndexOrThrow(KEY_USER_ROLE));

                users.add(new UserModel(id, name, email, phone, role));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return users;
    }

    public List<String> getRestaurantNames() {
        List<String> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + KEY_REST_NAME + " FROM " + TABLE_RESTAURANTS, null);

        if (cursor.moveToFirst()) {
            do {
                list.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        if (list.isEmpty()) {
            list.add("Manam Comfort Filipino");
            list.add("Kuya J Restaurant");
            list.add("Gerry's Grill");
            list.add("Barrio Fiesta");
            list.add("Jollibee");
            list.add("McDonald's");
            list.add("Mang Inasal");
        }
        return list;
    }

    public int getBookedSlotsCount(String restaurantName, String date, String timeSlot) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_RESERVATIONS + " WHERE "
                        + KEY_RES_RESTAURANT + "=? AND "
                        + KEY_RES_DATE + "=? AND "
                        + KEY_RES_TIME_SLOT + "=? AND "
                        + KEY_RES_STATUS + "!= 'CANCELLED'",
                new String[]{restaurantName, date, timeSlot});

        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public List<SlotModel> getSlotsForRestaurantAndDate(String restaurantName, String date) {
        List<SlotModel> slots = new ArrayList<>();
        int maxCapacity = 5; // Default 5 reservations allowed per slot

        for (String timeSlot : DEFAULT_TIME_SLOTS) {
            int booked = getBookedSlotsCount(restaurantName, date, timeSlot);
            slots.add(new SlotModel(timeSlot, maxCapacity, booked));
        }
        return slots;
    }


    public long createReservation(String userEmail, String userName, String userPhone,
                                  String restaurantName, String resDate, String resTimeSlot,
                                  int guestsCount, String specialNotes) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(KEY_RES_USER_EMAIL, userEmail);
        cv.put(KEY_RES_USER_NAME, userName);
        cv.put(KEY_RES_USER_PHONE, userPhone);
        cv.put(KEY_RES_RESTAURANT, restaurantName);
        cv.put(KEY_RES_DATE, resDate);
        cv.put(KEY_RES_TIME_SLOT, resTimeSlot);
        cv.put(KEY_RES_GUESTS, guestsCount);
        cv.put(KEY_RES_NOTES, specialNotes);
        cv.put(KEY_RES_STATUS, "CONFIRMED");

        return db.insert(TABLE_RESERVATIONS, null, cv);
    }

    public List<ReservationModel> getReservationsForUser(String userEmail) {
        List<ReservationModel> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_RESERVATIONS
                + " WHERE " + KEY_RES_USER_EMAIL + "=? ORDER BY " + KEY_RES_ID + " DESC", new String[]{userEmail});

        if (cursor.moveToFirst()) {
            do {
                list.add(parseReservationFromCursor(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    public List<ReservationModel> getAllReservations() {
        return getFilteredReservations("ALL", "ALL", "ALL");
    }

    public List<ReservationModel> getFilteredReservations(String restaurantFilter, String dateFilter, String statusFilter) {
        List<ReservationModel> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        StringBuilder query = new StringBuilder("SELECT * FROM " + TABLE_RESERVATIONS + " WHERE 1=1");
        List<String> args = new ArrayList<>();

        if (!restaurantFilter.equals("ALL") && !restaurantFilter.isEmpty()) {
            query.append(" AND ").append(KEY_RES_RESTAURANT).append("=?");
            args.add(restaurantFilter);
        }

        if (!dateFilter.equals("ALL") && !dateFilter.isEmpty()) {
            query.append(" AND ").append(KEY_RES_DATE).append("=?");
            args.add(dateFilter);
        }

        if (!statusFilter.equals("ALL") && !statusFilter.isEmpty()) {
            query.append(" AND ").append(KEY_RES_STATUS).append("=?");
            args.add(statusFilter);
        }

        query.append(" ORDER BY ").append(KEY_RES_ID).append(" DESC");

        Cursor cursor = db.rawQuery(query.toString(), args.toArray(new String[0]));

        if (cursor.moveToFirst()) {
            do {
                list.add(parseReservationFromCursor(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    public boolean updateReservationStatus(int reservationId, String newStatus) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(KEY_RES_STATUS, newStatus);

        int rows = db.update(TABLE_RESERVATIONS, cv, KEY_RES_ID + "=?", new String[]{String.valueOf(reservationId)});
        return rows > 0;
    }

    public boolean deleteReservation(int reservationId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_RESERVATIONS, KEY_RES_ID + "=?", new String[]{String.valueOf(reservationId)});
        return rows > 0;
    }

    public boolean clearAllReservations() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_RESERVATIONS);
        return true;
    }

    private ReservationModel parseReservationFromCursor(Cursor cursor) {
        int id = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_RES_ID));
        String userEmail = cursor.getString(cursor.getColumnIndexOrThrow(KEY_RES_USER_EMAIL));
        String userName = cursor.getString(cursor.getColumnIndexOrThrow(KEY_RES_USER_NAME));
        String userPhone = cursor.getString(cursor.getColumnIndexOrThrow(KEY_RES_USER_PHONE));
        String restaurant = cursor.getString(cursor.getColumnIndexOrThrow(KEY_RES_RESTAURANT));
        String date = cursor.getString(cursor.getColumnIndexOrThrow(KEY_RES_DATE));
        String timeSlot = cursor.getString(cursor.getColumnIndexOrThrow(KEY_RES_TIME_SLOT));
        int guests = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_RES_GUESTS));
        String notes = cursor.getString(cursor.getColumnIndexOrThrow(KEY_RES_NOTES));
        String status = cursor.getString(cursor.getColumnIndexOrThrow(KEY_RES_STATUS));
        String createdAt = cursor.getString(cursor.getColumnIndexOrThrow(KEY_RES_CREATED_AT));

        return new ReservationModel(id, userEmail, userName, userPhone, restaurant, date, timeSlot, guests, notes, status, createdAt);
    }


    public Map<String, Object> getAdminStats() {
        Map<String, Object> stats = new HashMap<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Total Users
        Cursor userCursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_USERS + " WHERE " + KEY_USER_ROLE + "='USER'", null);
        int totalUsers = 0;
        if (userCursor.moveToFirst()) totalUsers = userCursor.getInt(0);
        userCursor.close();

        // Total Reservations
        Cursor resCursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_RESERVATIONS, null);
        int totalRes = 0;
        if (resCursor.moveToFirst()) totalRes = resCursor.getInt(0);
        resCursor.close();

        Cursor activeCursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_RESERVATIONS + " WHERE " + KEY_RES_STATUS + "='CONFIRMED'", null);
        int activeRes = 0;
        if (activeCursor.moveToFirst()) activeRes = activeCursor.getInt(0);
        activeCursor.close();

        Cursor cancelCursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_RESERVATIONS + " WHERE " + KEY_RES_STATUS + "='CANCELLED'", null);
        int cancelRes = 0;
        if (cancelCursor.moveToFirst()) cancelRes = cancelCursor.getInt(0);
        cancelCursor.close();


        Cursor popCursor = db.rawQuery("SELECT " + KEY_RES_RESTAURANT + ", COUNT(*) as cnt FROM " + TABLE_RESERVATIONS
                + " GROUP BY " + KEY_RES_RESTAURANT + " ORDER BY cnt DESC LIMIT 1", null);
        String popularRest = "None";
        if (popCursor.moveToFirst()) {
            popularRest = popCursor.getString(0) + " (" + popCursor.getInt(1) + " bookings)";
        }
        popCursor.close();

        stats.put("totalUsers", totalUsers);
        stats.put("totalReservations", totalRes);
        stats.put("activeReservations", activeRes);
        stats.put("cancelledReservations", cancelRes);
        stats.put("popularRestaurant", popularRest);

        return stats;
    }
}
