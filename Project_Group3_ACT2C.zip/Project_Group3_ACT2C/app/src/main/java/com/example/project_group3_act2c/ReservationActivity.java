package com.example.project_group3_act2c;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ReservationActivity extends AppCompatActivity {

    private Spinner spinnerRestaurant;
    private EditText etDate;
    private TextView tvSlotNotice;
    private RecyclerView rvSlots;
    private EditText etGuests;
    private EditText etNotes;
    private Button btnConfirm;
    private Button btnBack;
    private ProgressBar progressBar;

    private DatabaseHelper dbHelper;
    private SlotAdapter slotAdapter;
    private String selectedRestaurant = "";
    private String selectedDate = "";
    private SlotModel selectedSlot = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);

        dbHelper = new DatabaseHelper(this);

        spinnerRestaurant = findViewById(R.id.spinnerRestaurant);
        etDate = findViewById(R.id.etDate);
        tvSlotNotice = findViewById(R.id.tvSlotNotice);
        rvSlots = findViewById(R.id.rvSlots);
        etGuests = findViewById(R.id.etGuests);
        etNotes = findViewById(R.id.etNotes);
        btnConfirm = findViewById(R.id.btnConfirm);
        btnBack = findViewById(R.id.btnBack);
        progressBar = findViewById(R.id.progressBar);

        rvSlots.setLayoutManager(new GridLayoutManager(this, 2));
        slotAdapter = new SlotAdapter(this, null, slot -> {
            selectedSlot = slot;
        });
        rvSlots.setAdapter(slotAdapter);

        setupRestaurantSpinner();
        setupFilipinoQuickSelectChips();
        setupDatePicker();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        selectedDate = sdf.format(new Date());
        etDate.setText(selectedDate);
        loadAvailableSlots();

        btnConfirm.setOnClickListener(v -> confirmReservation());
        btnBack.setOnClickListener(v -> finish());
    }

    private void setupRestaurantSpinner() {
        List<String> restaurants = dbHelper.getRestaurantNames();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, restaurants);
        spinnerRestaurant.setAdapter(adapter);

        String prefilledRestaurant = getIntent().getStringExtra("restaurant_name");
        if (prefilledRestaurant != null && !prefilledRestaurant.isEmpty()) {
            int pos = restaurants.indexOf(prefilledRestaurant);
            if (pos >= 0) {
                spinnerRestaurant.setSelection(pos);
            }
        }

        spinnerRestaurant.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedRestaurant = restaurants.get(position);
                loadAvailableSlots();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void setupFilipinoQuickSelectChips() {
        TextView chipManam = findViewById(R.id.chipManam);
        TextView chipKuyaJ = findViewById(R.id.chipKuyaJ);
        TextView chipGerrys = findViewById(R.id.chipGerrys);
        TextView chipBarrio = findViewById(R.id.chipBarrio);
        TextView chipJollibee = findViewById(R.id.chipJollibee);
        TextView chipMcDonalds = findViewById(R.id.chipMcDonalds);
        TextView chipMangInasal = findViewById(R.id.chipMangInasal);

        if (chipManam != null) chipManam.setOnClickListener(v -> selectRestaurantByName("Manam Comfort Filipino"));
        if (chipKuyaJ != null) chipKuyaJ.setOnClickListener(v -> selectRestaurantByName("Kuya J Restaurant"));
        if (chipGerrys != null) chipGerrys.setOnClickListener(v -> selectRestaurantByName("Gerry's Grill"));
        if (chipBarrio != null) chipBarrio.setOnClickListener(v -> selectRestaurantByName("Barrio Fiesta"));
        if (chipJollibee != null) chipJollibee.setOnClickListener(v -> selectRestaurantByName("Jollibee"));
        if (chipMcDonalds != null) chipMcDonalds.setOnClickListener(v -> selectRestaurantByName("McDonald's"));
        if (chipMangInasal != null) chipMangInasal.setOnClickListener(v -> selectRestaurantByName("Mang Inasal"));
    }

    private void selectRestaurantByName(String name) {
        List<String> restaurants = dbHelper.getRestaurantNames();
        int pos = restaurants.indexOf(name);
        if (pos >= 0) {
            spinnerRestaurant.setSelection(pos);
            Toast.makeText(this, "Selected: " + name, Toast.LENGTH_SHORT).show();
        }
    }

    private void setupDatePicker() {
        etDate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    ReservationActivity.this,
                    (view, selectedYear, selectedMonth, selectedDay) -> {
                        selectedDate = String.format(Locale.getDefault(), "%04d-%02d-%02d",
                                selectedYear, selectedMonth + 1, selectedDay);
                        etDate.setText(selectedDate);
                        loadAvailableSlots();
                    },
                    year, month, day
            );
            datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
            datePickerDialog.show();
        });
    }

    private void loadAvailableSlots() {
        if (selectedRestaurant.isEmpty() || selectedDate.isEmpty()) {
            return;
        }

        tvSlotNotice.setText("Available slots for " + selectedRestaurant + " on " + selectedDate + ":");
        List<SlotModel> slots = dbHelper.getSlotsForRestaurantAndDate(selectedRestaurant, selectedDate);
        slotAdapter.setSlots(slots);
        selectedSlot = null;
    }

    private void confirmReservation() {
        selectedSlot = slotAdapter.getSelectedSlot();
        String guestsStr = etGuests.getText().toString().trim();
        String notes = etNotes != null ? etNotes.getText().toString().trim() : "";

        if (selectedRestaurant.isEmpty()) {
            Toast.makeText(this, "Please select a restaurant", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedDate.isEmpty()) {
            Toast.makeText(this, "Please select a date", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedSlot == null) {
            Toast.makeText(this, "Please select an available time slot", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!selectedSlot.isAvailable()) {
            Toast.makeText(this, "Selected slot is fully booked. Choose another slot.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (guestsStr.isEmpty()) {
            Toast.makeText(this, "Please enter the number of guests", Toast.LENGTH_SHORT).show();
            return;
        }

        int guestsCount = Integer.parseInt(guestsStr);
        if (guestsCount <= 0 || guestsCount > 30) {
            Toast.makeText(this, "Please enter a valid guest count (1 - 30)", Toast.LENGTH_SHORT).show();
            return;
        }


        SharedPreferences userPrefs = getSharedPreferences("UserData", MODE_PRIVATE);
        String userName = userPrefs.getString("name", "Guest User");
        String userEmail = userPrefs.getString("email", "guest@foodie.com");
        String userPhone = userPrefs.getString("phone", "09000000000");

        if (progressBar != null) {
            progressBar.setVisibility(View.VISIBLE);
        }
        btnConfirm.setEnabled(false);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (progressBar != null) {
                progressBar.setVisibility(View.GONE);
            }
            btnConfirm.setEnabled(true);

            long rowId = dbHelper.createReservation(
                    userEmail, userName, userPhone,
                    selectedRestaurant, selectedDate, selectedSlot.getTimeSlot(),
                    guestsCount, notes
            );

            if (rowId != -1) {

                SharedPreferences resPrefs = getSharedPreferences("ReservationData", MODE_PRIVATE);
                resPrefs.edit()
                        .putBoolean("has_reservation", true)
                        .putString("res_restaurant", selectedRestaurant)
                        .putString("res_date", selectedDate)
                        .putString("res_time", selectedSlot.getTimeSlot())
                        .putString("res_guests", guestsStr)
                        .putString("res_notes", notes)
                        .apply();

                Toast.makeText(this, "Reservation Confirmed for " + selectedSlot.getTimeSlot() + "!", Toast.LENGTH_LONG).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to create reservation. Please try again.", Toast.LENGTH_SHORT).show();
            }
        }, 800);
    }
}
