package com.example.project_group3_act2c;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ForgotPasswordActivity extends AppCompatActivity {

    private boolean isNewPasswordVisible = false;
    private boolean isConfirmPasswordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        EditText etEmail = findViewById(R.id.etEmail);
        EditText etNewPassword = findViewById(R.id.etNewPassword);
        EditText etConfirmPassword = findViewById(R.id.etConfirmPassword);
        ImageView ivToggleNewPassword = findViewById(R.id.ivToggleNewPassword);
        ImageView ivToggleConfirmPassword = findViewById(R.id.ivToggleConfirmPassword);
        Button btnReset = findViewById(R.id.btnReset);
        ProgressBar progressBar = findViewById(R.id.progressBar);
        TextView tvBackLogin = findViewById(R.id.tvBackLogin);

        if (ivToggleNewPassword != null) {
            ivToggleNewPassword.setOnClickListener(v -> {
                isNewPasswordVisible = !isNewPasswordVisible;
                if (isNewPasswordVisible) {
                    etNewPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    ivToggleNewPassword.setImageResource(R.drawable.ic_eye);
                } else {
                    etNewPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    ivToggleNewPassword.setImageResource(R.drawable.ic_eye_off);
                }
                etNewPassword.setSelection(etNewPassword.getText().length());
            });
        }

        if (ivToggleConfirmPassword != null) {
            ivToggleConfirmPassword.setOnClickListener(v -> {
                isConfirmPasswordVisible = !isConfirmPasswordVisible;
                if (isConfirmPasswordVisible) {
                    etConfirmPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    ivToggleConfirmPassword.setImageResource(R.drawable.ic_eye);
                } else {
                    etConfirmPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    ivToggleConfirmPassword.setImageResource(R.drawable.ic_eye_off);
                }
                etConfirmPassword.setSelection(etConfirmPassword.getText().length());
            });
        }

        btnReset.setOnClickListener(v -> {

            String email = etEmail.getText().toString().trim();
            String newPassword = etNewPassword.getText().toString();
            String confirmPassword = etConfirmPassword.getText().toString();

            SharedPreferences prefs = getSharedPreferences("UserData", MODE_PRIVATE);
            String savedEmail = prefs.getString("email", "");

            if (email.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(this, "Please complete all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!email.equalsIgnoreCase(savedEmail)) {
                Toast.makeText(this, "Email not found", Toast.LENGTH_SHORT).show();
                return;
            }

            if (newPassword.length() < 6) {
                Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!newPassword.equals(confirmPassword)) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }

            if (progressBar != null) {
                progressBar.setVisibility(View.VISIBLE);
            }
            btnReset.setEnabled(false);

            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (progressBar != null) {
                    progressBar.setVisibility(View.GONE);
                }
                btnReset.setEnabled(true);

                prefs.edit()
                        .putString("password", newPassword)
                        .apply();

                Toast.makeText(this, "Password updated successfully!", Toast.LENGTH_LONG).show();
                finish();
            }, 800);
        });

        tvBackLogin.setOnClickListener(v -> finish());
    }
}
