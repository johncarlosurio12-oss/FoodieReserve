package com.example.project_group3_act2c;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AdminDashboardActivity extends AppCompatActivity {

    private TextView tvAdminStats;
    private Button btnViewUsers;

    private Spinner spinnerInspectorRest;
    private EditText etInspectorDate;
    private RecyclerView rvSlotInspector;

    private Spinner spinnerFilterRestaurant;
    private Spinner spinnerFilterStatus;
    private TextView tvAdminNoReservations;
    private RecyclerView rvAdminReservations;

    private Button btnAdminClearAll;
    private Button btnAdminLogout;
    private ProgressBar progressBar;

    private DatabaseHelper dbHelper;
    private ReservationAdapter reservationAdapter;
    private SlotAdapter slotInspectorAdapter;

    private String selectedInspectorRest = "";
    private String selectedInspectorDate = "";

    private String selectedFilterRest = "ALL";
    private String selectedFilterStatus = "ALL";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        dbHelper = new DatabaseHelper(this);

        tvAdminStats = findViewById(R.id.tvAdminStats);
        btnViewUsers = findViewById(R.id.btnViewUsers);

        spinnerInspectorRest = findViewById(R.id.spinnerAdminInspectorRest);
        etInspectorDate = findViewById(R.id.etAdminInspectorDate);
        rvSlotInspector = findViewById(R.id.rvAdminSlotInspector);

        spinnerFilterRestaurant = findViewById(R.id.spinnerFilterRestaurant);
        spinnerFilterStatus = findViewById(R.id.spinnerFilterStatus);
        tvAdminNoReservations = findViewById(R.id.tvAdminNoReservations);
        rvAdminReservations = findViewById(R.id.rvAdminReservations);

        btnAdminClearAll = findViewById(R.id.btnAdminClearAll);
        btnAdminLogout = findViewById(R.id.btnAdminLogout);
        progressBar = findViewById(R.id.progressBar);

        // Setup Slot Inspector
        rvSlotInspector.setLayoutManager(new GridLayoutManager(this, 2));
        slotInspectorAdapter = new SlotAdapter(this, null, null);
        rvSlotInspector.setAdapter(slotInspectorAdapter);

        // Setup Reservations RecyclerView
        rvAdminReservations.setLayoutManager(new LinearLayoutManager(this));
        reservationAdapter = new ReservationAdapter(this, null, true, new ReservationAdapter.OnReservationActionListener() {
            @Override
            public void onCancel(ReservationModel reservation) {
                updateStatus(reservation.getId(), "CANCELLED");
            }

            @Override
            public void onApprove(ReservationModel reservation) {
                updateStatus(reservation.getId(), "CONFIRMED");
            }

            @Override
            public void onComplete(ReservationModel reservation) {
                updateStatus(reservation.getId(), "COMPLETED");
            }

            @Override
            public void onDelete(ReservationModel reservation) {
                deleteReservation(reservation.getId());
            }
        });
        rvAdminReservations.setAdapter(reservationAdapter);

        setupInspectorControls();
        setupFilterSpinners();

        btnViewUsers.setOnClickListener(v -> showUsersDialog());

        btnAdminClearAll.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Clear All Reservations")
                    .setMessage("Are you sure you want to delete all system reservations? This action cannot be undone.")
                    .setPositiveButton("Yes, Clear All", (dialog, which) -> clearAllReservations())
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        btnAdminLogout.setOnClickListener(v -> {
            if (progressBar != null) {
                progressBar.setVisibility(View.VISIBLE);
            }
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (progressBar != null) {
                    progressBar.setVisibility(View.GONE);
                }
                Intent intent = new Intent(AdminDashboardActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }, 500);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadAllData();
    }

    private void loadAllData() {
        loadStats();
        loadInspectorSlots();
        loadReservations();
    }

    private void loadStats() {
        Map<String, Object> stats = dbHelper.getAdminStats();
        int totalUsers = (int) stats.get("totalUsers");
        int totalRes = (int) stats.get("totalReservations");
        int activeRes = (int) stats.get("activeReservations");
        int cancelRes = (int) stats.get("cancelledReservations");
        String popRest = (String) stats.get("popularRestaurant");

        StringBuilder sb = new StringBuilder();
        sb.append("Total Registered Users: ").append(totalUsers)
                .append("\nTotal System Reservations: ").append(totalRes)
                .append("\nActive/Confirmed: ").append(activeRes)
                .append(" | Cancelled: ").append(cancelRes)
                .append("\nPopular Restaurant: ").append(popRest);

        tvAdminStats.setText(sb.toString());
    }

    private void setupInspectorControls() {
        List<String> restaurants = dbHelper.getRestaurantNames();
        ArrayAdapter<String> restAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, restaurants);
        spinnerInspectorRest.setAdapter(restAdapter);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        selectedInspectorDate = sdf.format(new Date());
        etInspectorDate.setText(selectedInspectorDate);

        spinnerInspectorRest.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedInspectorRest = restaurants.get(position);
                loadInspectorSlots();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        etInspectorDate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    AdminDashboardActivity.this,
                    (view, year, month, day) -> {
                        selectedInspectorDate = String.format(Locale.getDefault(), "%04d-%02d-%02d", year, month + 1, day);
                        etInspectorDate.setText(selectedInspectorDate);
                        loadInspectorSlots();
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );
            datePickerDialog.show();
        });
    }

    private void loadInspectorSlots() {
        if (selectedInspectorRest.isEmpty() || selectedInspectorDate.isEmpty()) return;
        List<SlotModel> slots = dbHelper.getSlotsForRestaurantAndDate(selectedInspectorRest, selectedInspectorDate);
        slotInspectorAdapter.setSlots(slots);
    }

    private void setupFilterSpinners() {
        List<String> filterRestList = new ArrayList<>();
        filterRestList.add("ALL RESTAURANTS");
        filterRestList.addAll(dbHelper.getRestaurantNames());

        ArrayAdapter<String> restFilterAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, filterRestList);
        spinnerFilterRestaurant.setAdapter(restFilterAdapter);

        List<String> statusList = new ArrayList<>();
        statusList.add("ALL STATUSES");
        statusList.add("CONFIRMED");
        statusList.add("PENDING");
        statusList.add("CANCELLED");
        statusList.add("COMPLETED");

        ArrayAdapter<String> statusFilterAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, statusList);
        spinnerFilterStatus.setAdapter(statusFilterAdapter);

        spinnerFilterRestaurant.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedFilterRest = position == 0 ? "ALL" : filterRestList.get(position);
                loadReservations();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        spinnerFilterStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedFilterStatus = position == 0 ? "ALL" : statusList.get(position);
                loadReservations();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void loadReservations() {
        List<ReservationModel> list = dbHelper.getFilteredReservations(selectedFilterRest, "ALL", selectedFilterStatus);

        if (list == null || list.isEmpty()) {
            tvAdminNoReservations.setVisibility(View.VISIBLE);
            rvAdminReservations.setVisibility(View.GONE);
        } else {
            tvAdminNoReservations.setVisibility(View.GONE);
            rvAdminReservations.setVisibility(View.VISIBLE);
            reservationAdapter.setReservations(list);
        }
    }

    private void updateStatus(int reservationId, String newStatus) {
        if (progressBar != null) progressBar.setVisibility(View.VISIBLE);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (progressBar != null) progressBar.setVisibility(View.GONE);
            boolean updated = dbHelper.updateReservationStatus(reservationId, newStatus);
            if (updated) {
                Toast.makeText(this, "Reservation status updated to " + newStatus, Toast.LENGTH_SHORT).show();
                loadAllData();
            } else {
                Toast.makeText(this, "Failed to update reservation", Toast.LENGTH_SHORT).show();
            }
        }, 300);
    }

    private void deleteReservation(int reservationId) {
        if (progressBar != null) progressBar.setVisibility(View.VISIBLE);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (progressBar != null) progressBar.setVisibility(View.GONE);
            boolean deleted = dbHelper.deleteReservation(reservationId);
            if (deleted) {
                Toast.makeText(this, "Reservation deleted from database", Toast.LENGTH_SHORT).show();
                loadAllData();
            } else {
                Toast.makeText(this, "Failed to delete reservation", Toast.LENGTH_SHORT).show();
            }
        }, 300);
    }

    private void clearAllReservations() {
        if (progressBar != null) progressBar.setVisibility(View.VISIBLE);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (progressBar != null) progressBar.setVisibility(View.GONE);
            dbHelper.clearAllReservations();

            SharedPreferences resPrefs = getSharedPreferences("ReservationData", MODE_PRIVATE);
            resPrefs.edit().clear().apply();

            Toast.makeText(this, "All reservations cleared", Toast.LENGTH_SHORT).show();
            loadAllData();
        }, 400);
    }

    private void showUsersDialog() {
        List<UserModel> users = dbHelper.getAllUsers();
        if (users.isEmpty()) {
            Toast.makeText(this, "No registered users found", Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < users.size(); i++) {
            UserModel u = users.get(i);
            sb.append(i + 1).append(". ").append(u.getName())
                    .append("\n   Email: ").append(u.getEmail())
                    .append("\n   Phone: ").append(u.getPhone())
                    .append("\n   Role: ").append(u.getRole())
                    .append("\n\n");
        }

        new AlertDialog.Builder(this)
                .setTitle("Registered System Users")
                .setMessage(sb.toString().trim())
                .setPositiveButton("Close", null)
                .show();
    }
}
