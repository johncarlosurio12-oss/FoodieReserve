package com.example.project_group3_act2c;

public class UserModel {
    private int id;
    private String name;
    private String email;
    private String phone;
    private String role;

    public UserModel(int id, String name, String email, String phone, String role) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.role = role;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getRole() { return role; }
}
